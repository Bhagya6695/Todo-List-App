//getting the username and password
var usrname = document.querySelector("#name");
var passwrd = document.querySelector("#paswrd");
var btn = document.getElementById("butn");
var error = document.querySelector("#error");
var paserror = document.querySelector("#paserror");
error.innerHTML="";
paserror.innerHTML="";

btn.addEventListener("click",function(){
    error.innerHTML=" ";
    paserror.innerHTML=" ";
    login(main);
});

function login(callback)
{  
    if(usrname.value=="admin" && passwrd.value=="12345")
    {
      callback();       }
   
    else if(usrname.value!="admin" || usrname.value=="")
    {
        usrname.focus();
        error.innerHTML="Invalid username" 
        error.style.fontSize= "x-small"; 
        error.style.color ="red";
      }

   else if(passwrd.value!=12345 || usrname.value == "")
   {
    paserror.innerHTML="Wrong password!!" 
    paserror.style.fontSize= "x-small"; 
    paserror.style.color ="red";
   }
}
function main(){
    // document.getElementById("demo").style.innerHTML=window.location.assign("index.html");
    window.location.href="home.html";
    return true; 
}
 


