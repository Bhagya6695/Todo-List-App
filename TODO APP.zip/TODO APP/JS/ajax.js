$(document).ready(function(){
var Uid = document.querySelector("#userId");
var Id = document.querySelector("#Id");
var title = document.querySelector("#Title");
var completed= document.querySelector("#Completed");
var checkbox = document.querySelector("#check");
var todo = document.getElementById("todo");

todo.addEventListener("click",function(){
    todolist();
});

function todolist(){

    // Uid.innerHTML="UserId  ";
    Id.innerHTML="Id   ";    
    title.innerHTML="Title";
    completed.innerHTML="Completed ";
    checkbox.innerHTML="checkbox";
  

    let xhr = new XMLHttpRequest;
    
    xhr.onload = function() 
    {
      if (this.status == 200) 
      { 
          let data = JSON.parse(this.responseText),
                tbodyHtml = '';
                var checkbox = document.createElement("INPUT");  
        data.map(function(d) {
            tbodyHtml += `
              <tr>
                <th colspan="2">${d.id}</th>
                <th colspan="2">${d.title}</th>
                <td colspan="2">${d.completed} </td>
                <td colspan="2"><input type="checkbox" name="name1" id="${d.userid}"/> &nbsp;</td>
                
            </tr>
         `;
        });       
        document.querySelector('#tab tbody').innerHTML = tbodyHtml;

        // checkbox.attr('id', 'checkbox'+checkbox.index()); // Adding ID attribute


        $.each(data, function(i, item) {
            if(data.completed!="false"){
            $('#tab :input[type="checkbox"]').prop("checked",true);
                   }
            
            else{
                $('#tab :input[type="checkbox"]').prop("checked",false);

            }
        });
       
    //     for(let i=0;i<data.length;i++){
    //         if((data[i].completed)){
    //             // for(let j=i;j<data.length;j++){
    //             // $(":checkbox").filter(${'data[i].completed}').attr("checked","true");​
    //             // data[j].userid.disabled="true";
    //             $('#tab :input[type="checkbox"]').prop("checked",true);
    //             $('#tab :input[type="checkbox"]').prop("disabled",true);
                
            
    //     } console.log(data[i].completed);
    // }

        

    
        var promise = new Promise(function(resolve,reject){
            var limit = 5;
            $(':checkbox').click(function() {
           var s=$('#tab :input[type="checkbox"]:checked').length;
                if(s==5){
                    resolve();
                    console.log("success");
                }
                
            });  
            });
        
          promise
          .then (function(){
              alert("Done!!you have successfully completed the task");
          })  
          .catch(function(){
              console.log("error");
          })
          
        
      }
    }
    xhr.open('GET', 'https://jsonplaceholder.typicode.com/todos', true);

    xhr.send();
}

});