$(document).ready(function(){
    var Uid = document.querySelector("#userId");
    var Id = document.querySelector("#Id");
    var title = document.querySelector("#Title");
    var completed= document.querySelector("#Completed");
    var checkbox = document.querySelector("#check");
    var todo = document.getElementById("todo");
    var heading= document.querySelector("#heading");
    todo.addEventListener("click",function(){
        todolist();
    });
    

    function todolist(){
        heading.innerHTML="Please complete any 5 tasks by clicking on the checkbox!!" ;

        // Uid.innerHTML="UserId  ";
        Id.innerHTML="Id   ";    
        title.innerHTML="Title";
        completed.innerHTML="Completed ";
        checkbox.innerHTML="Checkbox";
      
    
        let xhr = new XMLHttpRequest;
        
        xhr.onload = function() 
        {
          if (this.status == 200) 
          { 
              let data = JSON.parse(this.responseText),
                    task = '';
                $.each(data,function(key,value) {
                    task+='<tr>';
                    task+='<td colspan="2">'+value.id+'</td>';
                    task+='<td colspan="2">'+value.title+'</td>';
                    task+='<td colspan="2">'+value.completed+'</td>';
                    task+='<td colspan="2">';

                    if(value.completed==false){

                        task+='<input type="checkbox" id="check" class="checkbox"> ';
                      }

                    else{
                        task+='<input type="checkbox" checked disabled> ';
                         }
                         task+='</td>';
                        task+='</tr>';
                });
            document.querySelector('#tab tbody').innerHTML = task;
    
               
    
            //promise
    
            var promise = new Promise(function(resolve,reject){
                var count = 0;
                $(':checkbox').click(function() {
                    if(this.checked){
                        count++;
                    }

                    if(count==5){
                        resolve();
                        console.log("success");
                    }
                    
                });  
                });
            
              promise
              .then (function(){
                  alert("Congradulations!!  you have successfully completed the task!!");
              })  
              .catch(function(){
                  console.log("error");
              })
            
              
            //end of promise
    
          }
        }
        xhr.open('GET', 'https://jsonplaceholder.typicode.com/todos', true);
    
        xhr.send();
    }
    
    });
    
    